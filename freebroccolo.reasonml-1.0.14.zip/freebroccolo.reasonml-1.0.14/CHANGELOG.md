## 1.0.0

* Fix highlighting for punned arguments.

## 0.0.99

* Fix bug with format-on-save.

## 0.0.98

* Added format-on-save thanks to Iwan Karamazow (see the `reason.formatOnSave` setting).
