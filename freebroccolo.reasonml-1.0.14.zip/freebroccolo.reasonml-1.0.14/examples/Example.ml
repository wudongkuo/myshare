class foo bar baz = object
  method field0 = bar + 1
  method field1 = baz ^ ""
end
